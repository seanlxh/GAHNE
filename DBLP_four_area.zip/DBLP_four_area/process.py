paths = ["author_label.txt"]
train_file = "all_label_train_id.txt"
test_file = "all_label_test_id.txt"

all_id = []

from random import shuffle

for path in paths:
    with open(path, 'r') as f: # 清空文件内容再写
        lines = f.readlines()
        for line in lines:
            content = line.split("\n")[0]
            id = int(content.split("\t")[0])
            all_id.append(id)

f1 = open(train_file, 'w')  # 清空文件内容再写
f2 = open(test_file, 'w')  # 清空文件内容再写

shuffle(all_id)
train_ratio = 0.15
count = train_ratio * len(all_id)
for i in range(len(all_id)):
    if i < count:
        f1.write(str(all_id[i]) + " ")
    else:
        f2.write(str(all_id[i]) + " ")

print(count)
print(len(all_id))

f1.close()
f2.close()